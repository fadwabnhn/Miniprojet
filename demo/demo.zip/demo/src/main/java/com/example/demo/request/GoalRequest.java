package com.example.demo.request;

public class GoalRequest {

    private Long userId;
    private String skill;
    private String suggestedGoal;
    private int time;

    public GoalRequest() {}

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getSuggestedGoal() {
        return suggestedGoal;
    }

    public void setSuggestedGoal(String suggestedGoal) {
        this.suggestedGoal = suggestedGoal;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
}
