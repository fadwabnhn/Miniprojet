package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_goals")
public class UserGoal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String skill;

    private String suggestedGoal;

    private int time;

    private String strategies;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // ===== constructor =====
    public UserGoal() {}

    // ===== getters & setters =====
    public Long getId() {
        return id;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getSuggestedGoal() {
        return suggestedGoal;
    }

    public void setSuggestedGoal(String suggestedGoal) {
        this.suggestedGoal = suggestedGoal;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public String getStrategies() {
        return strategies;
    }

    public void setStrategies(String strategies) {
        this.strategies = strategies;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
