package com.example.demo.response;

public class GoalResponse {

    private Long goalId;

    public GoalResponse(Long goalId) {
        this.goalId = goalId;
    }

    public Long getGoalId() {
        return goalId;
    }

    public void setGoalId(Long goalId) {
        this.goalId = goalId;
    }
}
