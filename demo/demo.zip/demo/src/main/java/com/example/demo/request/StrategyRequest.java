package com.example.demo.request;

import java.util.List;

public class StrategyRequest {

    private Long goalId;
    private List<String> strategies;

    public Long getGoalId() {
        return goalId;
    }

    public void setGoalId(Long goalId) {
        this.goalId = goalId;
    }

    public List<String> getStrategies() {
        return strategies;
    }

    public void setStrategies(List<String> strategies) {
        this.strategies = strategies;
    }
}
