package com.example.demo.controller;
import com.example.demo.entity.UserGoal;
import com.example.demo.request.GoalRequest;
import com.example.demo.request.StrategyRequest;
import com.example.demo.response.GoalResponse;
import com.example.demo.service.GoalService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/goals")
@CrossOrigin
public class GoalController {
    private final GoalService goalService;
    public GoalController(GoalService goalService) {
        this.goalService = goalService;
    }
    @PostMapping
    public ResponseEntity<GoalResponse> saveGoal(
            @RequestBody GoalRequest request) {
        UserGoal savedGoal = goalService.saveGoal(request);
        return ResponseEntity.ok(
                new GoalResponse(savedGoal.getId())
        );
    }
    @PostMapping("/strategies")
    public ResponseEntity<?> saveStrategies(
            @RequestBody StrategyRequest request) {

        goalService.saveStrategies(request);

        return ResponseEntity.ok().build();
    }


}
