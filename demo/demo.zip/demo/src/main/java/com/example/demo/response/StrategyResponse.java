package com.example.demo.response;


public class StrategyResponse {

    private String message;

    public StrategyResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
