package com.example.demo.service;
import com.example.demo.request.GoalRequest;
import com.example.demo.entity.User;
import com.example.demo.entity.UserGoal;
import com.example.demo.repository.UserGoalRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.request.StrategyRequest;
import org.springframework.stereotype.Service;
@Service
public class GoalService {
    private final UserRepository userRepository;
    private final UserGoalRepository goalRepository;

    // Constructor Injection (أفضل ممارسة)
    public GoalService(UserRepository userRepository,
                       UserGoalRepository goalRepository) {
        this.userRepository = userRepository;
        this.goalRepository = goalRepository;
    }
    public UserGoal saveGoal(GoalRequest request) {
   User user = userRepository.findById(request.getUserId())
                .orElseThrow(() ->
                        new RuntimeException("User not found with id: "
                                + request.getUserId()));

        // 2️⃣ إنشاء الهدف
        UserGoal goal = new UserGoal();
        goal.setSkill(request.getSkill());
        goal.setSuggestedGoal(request.getSuggestedGoal());
        goal.setTime(request.getTime());
        // 3️⃣ ربط الهدف بالمستخدم
        goal.setUser(user);
        // 4️⃣ الحفظ + الإرجاع
        return goalRepository.save(goal);
    }
    public void saveStrategies(StrategyRequest request) {
        UserGoal goal = goalRepository
                .findById(request.getGoalId())
                .orElseThrow(() -> new RuntimeException("Goal not found"));
        // نحفظ الاستراتيجيات كنص (أو JSON)
        goal.setStrategies(String.join(",", request.getStrategies()));
        goalRepository.save(goal);
    }
}
