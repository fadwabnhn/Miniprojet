package com.example.demo.controller;


import com.example.demo.request.ProfileRequest;
import com.example.demo.entity.User;
import com.example.demo.entity.UserProfile;
import com.example.demo.repository.UserProfileRepository;
import com.example.demo.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/profile")
@CrossOrigin
public class UserProfileController {

    @Autowired
    private UserProfileRepository profileRepo;

    @Autowired
    private UserRepository userRepo;

    @PostMapping("/save")
    public ResponseEntity<String> saveProfile(
            @RequestBody ProfileRequest request) {

        User user = userRepo.findById(request.getUserId())
                .orElse(null);

        if (user == null) {
            return ResponseEntity.badRequest().body("User not found");
        }

        UserProfile profile = new UserProfile();
        profile.setName(request.getName());
        profile.setLevel(request.getLevel());
        profile.setPreference(request.getPreference());
        profile.setTimeSelected(request.getTimeSelected());
        profile.setUser(user);

        profileRepo.save(profile);

        return ResponseEntity.ok("Profile saved successfully");
    }
}

